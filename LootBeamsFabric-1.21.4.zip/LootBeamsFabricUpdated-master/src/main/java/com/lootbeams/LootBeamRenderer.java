package com.lootbeams;

import com.google.common.collect.Lists;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TextVisitFactory;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.StringHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Optional;

public final class LootBeamRenderer {

	/**
	 * ISSUES:
	 * Beam renders behind things like chests/clouds/water/beds/entities.
	 */

	private static final Identifier LOOT_BEAM_TEXTURE = Identifier.of(LootBeams.MODID, "textures/entity/loot_beam.png");

	private LootBeamRenderer() {
	}

	/**
	 * Same layer vanilla uses for beacon beams (translucent, full-bright, POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL).
	 * Replaces the old reflection hack on the private RenderLayer.of(...).
	 */
	private static RenderLayer beamLayer() {
		return RenderLayer.getBeaconBeam(LOOT_BEAM_TEXTURE, true);
	}

	public static void renderLootBeam(MatrixStack stack, VertexConsumerProvider buffer, float pticks, long worldtime, ItemEntity item) {
		float beamAlpha = LootBeams.config.beamAlpha;
		float fadeDistance = LootBeams.config.fadeDistance;
		//Fade out when close
		var player = MinecraftClient.getInstance().player;
		var distance = player.squaredDistanceTo(item);
		if (distance < fadeDistance) {
			beamAlpha *= Math.max(0, distance - fadeDistance + 1);
		}
		//Dont render beam if its too transparent
		if (beamAlpha <= 0.1f) {
			return;
		}

		float glowAlpha = beamAlpha * 0.4f;

		float beamRadius = 0.05f * LootBeams.config.beamRadius;
		float glowRadius = beamRadius + (beamRadius * 0.2f);
		float beamHeight = LootBeams.config.beamHeight;
		float yOffset = LootBeams.config.beamYOffset;

		TextColor color = getItemColor(item);
		float R = ((color.getRgb() >> 16) & 0xff) / 255f;
		float G = ((color.getRgb() >> 8) & 0xff) / 255f;
		float B = (color.getRgb() & 0xff) / 255f;

		//I will rewrite the beam rendering code soon! I promise!

		VertexConsumer consumer = buffer.getBuffer(beamLayer());

		stack.push();

		//Render main beam
		stack.push();
		float rotation = (float) Math.floorMod(worldtime, 40L) + pticks;
		stack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rotation * 2.25F - 45.0F));
		stack.translate(0, yOffset, 0);
		stack.translate(0, 1, 0);
		stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(180));
		renderPart(stack, consumer, R, G, B, beamAlpha, beamHeight, 0.0F, beamRadius, beamRadius, 0.0F, -beamRadius, 0.0F, 0.0F, -beamRadius);
		stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-180));
		renderPart(stack, consumer, R, G, B, beamAlpha, beamHeight, 0.0F, beamRadius, beamRadius, 0.0F, -beamRadius, 0.0F, 0.0F, -beamRadius);
		stack.pop();

		//Render glow around main beam
		stack.translate(0, yOffset, 0);
		stack.translate(0, 1, 0);
		stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(180));
		renderPart(stack, consumer, R, G, B, glowAlpha, beamHeight, -glowRadius, -glowRadius, glowRadius, -glowRadius, -beamRadius, glowRadius, glowRadius, glowRadius);
		stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-180));
		renderPart(stack, consumer, R, G, B, glowAlpha, beamHeight, -glowRadius, -glowRadius, glowRadius, -glowRadius, -beamRadius, glowRadius, glowRadius, glowRadius);

		stack.pop();

		if (LootBeams.config.renderNametags) {
			renderNameTag(stack, buffer, item, color);
		}
	}

	private static void renderNameTag(MatrixStack stack, VertexConsumerProvider buffer, ItemEntity item, TextColor color) {
		//If player is crouching or looking at the item
		if (MinecraftClient.getInstance().player.isInSneakingPose() || (LootBeams.config.renderNametagsOnlook && isLookingAt(MinecraftClient.getInstance().player, item, LootBeams.config.nametagLookSensitivity))) {

			float foregroundAlpha = LootBeams.config.nametagTextAlpha;
			float backgroundAlpha = LootBeams.config.nametagBackgroundAlpha;
			double yOffset = LootBeams.config.nametagYOffset;
			int foregroundColor = (color.getRgb() & 0xffffff) | ((int) (255 * foregroundAlpha) << 24);
			int backgroundColor = (color.getRgb() & 0xffffff) | ((int) (255 * backgroundAlpha) << 24);

			stack.push();

			//Render nametags at heights based on player distance
			stack.translate(0.0D, Math.min(1D, MinecraftClient.getInstance().player.squaredDistanceTo(item) * 0.025D) + yOffset, 0.0D);
			//Face the camera (EntityRenderDispatcher.getRotation() is gone in 1.21.x)
			stack.multiply(MinecraftClient.getInstance().gameRenderer.getCamera().getRotation());

			float nametagScale = LootBeams.config.nametagScale;
			stack.scale(-0.02F * nametagScale, -0.02F * nametagScale, 0.02F * nametagScale);

			//Render stack counts on nametag
			TextRenderer fontrenderer = MinecraftClient.getInstance().textRenderer;
			String itemName = StringHelper.stripTextFormat(item.getStack().getName().getString());
			if (LootBeams.config.renderStackcount) {
				int count = item.getStack().getCount();
				if (count > 1) {
					itemName = itemName + " x" + count;
				}
			}

			//Move closer to the player so we dont render in beam, and render the tag
			stack.translate(0, 0, -10);
			RenderText(fontrenderer, stack, buffer, itemName, foregroundColor, backgroundColor, backgroundAlpha);


			DrawRarity(item, foregroundAlpha, backgroundAlpha, fontrenderer, stack, buffer);

			stack.pop();
		}
	}

	private static void DrawRarity(ItemEntity item,
								   float foregroundAlpha,
								   float backgroundAlpha,
								   TextRenderer fontRenderer,
								   MatrixStack stack,
								   VertexConsumerProvider buffer
	) {
		//Render small tags
		stack.translate(0.0D, 10, 0.0D);
		stack.scale(0.75f, 0.75f, 0.75f);

		//1.20.5+: getTooltip(Item.TooltipContext, PlayerEntity, TooltipType)
		List<Text> tooltip = item.getStack().getTooltip(Item.TooltipContext.create(item.getWorld()), null, TooltipType.BASIC);

		if (tooltip.size() < 2) {
			return;
		}

		Text tooltipRarity = tooltip.get(1);

		var rarityString = tooltipRarity.getString();

		//Render custom rarities
		if (!(LootBeams.config.customRarities.contains(rarityString) || AlwaysHasRarity(item.getStack())))
			return;


		TextColor rarityColor = LootBeams.config.whiteRarities ? TextColor.fromFormatting(Formatting.WHITE) : getRawColor(tooltipRarity);
		int foregroundColor = (rarityColor.getRgb() & 0xffffff) | ((int) (255 * foregroundAlpha) << 24);
		int backgroundColor = (rarityColor.getRgb() & 0xffffff) | ((int) (255 * backgroundAlpha) << 24);
		RenderText(fontRenderer, stack, buffer, rarityString, foregroundColor, backgroundColor, backgroundAlpha);
	}

	private static boolean AlwaysHasRarity(ItemStack item) {
		List<String> overrides = LootBeams.config.alwaysDrawRaritiesOn;
		if (overrides.isEmpty())
			return false;

		for (String name : overrides.stream().filter((s) -> (!s.isEmpty())).toList()) {
			if (Configuration.entryMatches(name, item))
				return true;
		}
		return false;
	}

	private static void RenderText(
			TextRenderer fontRenderer,
			MatrixStack stack,
			VertexConsumerProvider buffer,
			String text,
			int foregroundColor,
			int backgroundColor,
			float backgroundAlpha
	) {
		if (LootBeams.config.borders) {
			float w = -fontRenderer.getWidth(text) / 2f;
			int bg = ((int) (255 * backgroundAlpha) << 24); // black with the background alpha

			var matrix = stack.peek().getPositionMatrix();
			//Draws background (border) text
			fontRenderer.draw(text, w + 1f, 0, bg, false, matrix, buffer, TextRenderer.TextLayerType.NORMAL, 0, 0);
			fontRenderer.draw(text, w - 1f, 0, bg, false, matrix, buffer, TextRenderer.TextLayerType.NORMAL, 0, 0);
			fontRenderer.draw(text, w, 1f, bg, false, matrix, buffer, TextRenderer.TextLayerType.NORMAL, 0, 0);
			fontRenderer.draw(text, w, -1f, bg, false, matrix, buffer, TextRenderer.TextLayerType.NORMAL, 0, 0);

			//Draws foreground text in front of border
			stack.translate(0.0D, 0.0D, -0.01D);
			matrix = stack.peek().getPositionMatrix();
			fontRenderer.draw(text, w, 0, foregroundColor, false, matrix, buffer, TextRenderer.TextLayerType.NORMAL, 0, 15728864);
			stack.translate(0.0D, 0.0D, 0.01D);
		} else {
			fontRenderer.draw(text, (float) (-fontRenderer.getWidth(text) / 2), 0f, foregroundColor, false, stack.peek().getPositionMatrix(), buffer, TextRenderer.TextLayerType.NORMAL, backgroundColor, 15728864);
		}
	}

	/**
	 * Returns the color from the item's name, rarity, tag, or override.
	 */
	private static TextColor getItemColor(ItemEntity item) {
		if (LootBeams.CRASH_BLACKLIST.contains(item.getStack())) {
			return TextColor.fromFormatting(Formatting.WHITE);
		}

		try {
			ItemStack stack = item.getStack();

			//From Config Overrides
			TextColor override = Configuration.getColorFromItemOverrides(stack);
			if (override != null) {
				return override;
			}

			//From custom data (1.20.5+: NBT on stacks became data components)
			NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
			if (customData != null) {
				NbtCompound nbt = customData.copyNbt();
				if (nbt.contains("lootbeams.color")) {
					return Configuration.parseColor(nbt.getString("lootbeams.color"));
				}
			}

			//From Name
			if (LootBeams.config.renderNameColor) {
				TextColor nameColor = getRawColor(stack.getName());
				if (!nameColor.equals(TextColor.fromFormatting(Formatting.WHITE))) {
					return nameColor;
				}
			}

			//From Rarity
			if (LootBeams.config.renderRarityColor) {
				return TextColor.fromFormatting(switch (stack.getRarity()) {
					case COMMON -> Formatting.WHITE;
					case UNCOMMON -> Formatting.YELLOW;
					case RARE -> Formatting.AQUA;
					case EPIC -> Formatting.LIGHT_PURPLE;
				});
			}
			return TextColor.fromFormatting(Formatting.WHITE);
		} catch (Exception e) {
			LootBeams.LOGGER.error("Failed to get color for (" + item.getStack().toHoverableText() + "), added to temporary blacklist");
			LootBeams.CRASH_BLACKLIST.add(item.getStack());
			LootBeams.LOGGER.info("Temporary blacklist is now : ");
			for (ItemStack s : LootBeams.CRASH_BLACKLIST) {
				LootBeams.LOGGER.info(s.toHoverableText());
			}
			return TextColor.fromFormatting(Formatting.WHITE);
		}
	}

	/**
	 * Gets color from the first letter in the text component.
	 */
	private static TextColor getRawColor(Text text) {
		List<Style> list = Lists.newArrayList();
		text.visit((style, string) -> {
			TextVisitFactory.visitFormatted(string, style, (index, s, codePoint) -> {
				list.add(s);
				return true;
			});
			return Optional.empty();
		}, Style.EMPTY);
		if (!list.isEmpty() && list.get(0).getColor() != null) {
			return list.get(0).getColor();
		}
		return TextColor.fromFormatting(Formatting.WHITE);
	}

	private static void renderPart(MatrixStack stack, VertexConsumer builder, float red, float green, float blue, float alpha, float height, float radius_1, float radius_2, float radius_3, float radius_4, float radius_5, float radius_6, float radius_7, float radius_8) {
		MatrixStack.Entry matrixentry = stack.peek();
		renderQuad(matrixentry, builder, red, green, blue, alpha, height, radius_1, radius_2, radius_3, radius_4);
		renderQuad(matrixentry, builder, red, green, blue, alpha, height, radius_7, radius_8, radius_5, radius_6);
		renderQuad(matrixentry, builder, red, green, blue, alpha, height, radius_3, radius_4, radius_7, radius_8);
		renderQuad(matrixentry, builder, red, green, blue, alpha, height, radius_5, radius_6, radius_1, radius_2);
	}

	private static void renderQuad(MatrixStack.Entry entry, VertexConsumer builder, float red, float green, float blue, float alpha, float y, float z1, float texu1, float z, float texu) {
		addVertex(entry, builder, red, green, blue, alpha, y, z1, texu1, 1f, 0f);
		addVertex(entry, builder, red, green, blue, alpha, 0f, z1, texu1, 1f, 1f);
		addVertex(entry, builder, red, green, blue, alpha, 0f, z, texu, 0f, 1f);
		addVertex(entry, builder, red, green, blue, alpha, y, z, texu, 0f, 0f);
	}

	private static void addVertex(MatrixStack.Entry entry, VertexConsumer builder, float red, float green, float blue, float alpha, float y, float x, float z, float texu, float texv) {
		Matrix4f pose = entry.getPositionMatrix();
		// 1.20.5+: no more .next(), normals are written through the MatrixStack.Entry
		builder.vertex(pose, x, y, z).color(red, green, blue, alpha).texture(texu, texv).overlay(OverlayTexture.DEFAULT_UV).light(15728880).normal(entry, 0.0F, 1.0F, 0.0F);
	}

	/**
	 * Checks if the player is looking at the given entity, accuracy determines how close the player has to look.
	 */
	private static boolean isLookingAt(ClientPlayerEntity player, Entity target, double accuracy) {
		Vec3d difference = new Vec3d(target.getX() - player.getX(), target.getEyeY() - player.getEyeY(), target.getZ() - player.getZ());
		double length = difference.length();
		double dot = player.getRotationVec(1.0F).normalize().dotProduct(difference.normalize());
		return dot > 1.0D - accuracy / length && player.canSee(target);
	}

}
