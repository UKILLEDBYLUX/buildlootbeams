package com.lootbeams;

import net.minecraft.entity.ItemEntity;

/**
 * Duck interface mixed into ItemEntityRenderState. In 1.21.2+ the renderer's render() no longer
 * receives the entity, so we carry it (and the tick delta) over from updateRenderState().
 */
public interface LootBeamsRenderStateAccess {
	ItemEntity lootbeams$getEntity();

	float lootbeams$getTickDelta();

	void lootbeams$set(ItemEntity entity, float tickDelta);
}
