package com.lootbeams.mixin;

import com.lootbeams.LootBeamsRenderStateAccess;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.entity.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(ItemEntityRenderState.class)
public class ItemEntityRenderStateMixin implements LootBeamsRenderStateAccess {
	@Unique
	private ItemEntity lootbeams$entity;
	@Unique
	private float lootbeams$tickDelta;

	@Override
	public ItemEntity lootbeams$getEntity() {
		return lootbeams$entity;
	}

	@Override
	public float lootbeams$getTickDelta() {
		return lootbeams$tickDelta;
	}

	@Override
	public void lootbeams$set(ItemEntity entity, float tickDelta) {
		this.lootbeams$entity = entity;
		this.lootbeams$tickDelta = tickDelta;
	}
}
