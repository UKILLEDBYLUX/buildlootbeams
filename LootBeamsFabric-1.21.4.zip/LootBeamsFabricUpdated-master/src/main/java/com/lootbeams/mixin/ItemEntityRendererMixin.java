package com.lootbeams.mixin;

import com.lootbeams.LootBeamRenderer;
import com.lootbeams.LootBeams;
import com.lootbeams.LootBeamsRenderStateAccess;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.TridentItem;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {

	/**
	 * Remember which entity this render state belongs to (render() only gets the state in 1.21.2+).
	 */
	@Inject(method = "updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V", at = @At("TAIL"))
	private void lootbeams$captureEntity(ItemEntity entity, ItemEntityRenderState state, float tickDelta, CallbackInfo ci) {
		((LootBeamsRenderStateAccess) state).lootbeams$set(entity, tickDelta);
	}

	@Inject(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"))
	private void attemptRenderBeams(ItemEntityRenderState state, MatrixStack poseStack, VertexConsumerProvider buffer, int packedLight, CallbackInfo ci) {
		LootBeamsRenderStateAccess access = (LootBeamsRenderStateAccess) state;
		ItemEntity itemEntity = access.lootbeams$getEntity();
		if (itemEntity == null || LootBeams.config == null) {
			return;
		}
		var player = MinecraftClient.getInstance().player;
		if (player == null) {
			return;
		}
		if (player.squaredDistanceTo(itemEntity) > LootBeams.config.renderDistance * LootBeams.config.renderDistance) {
			return;
		}

		ItemStack stack = itemEntity.getStack();
		boolean shouldRender = false;
		if (LootBeams.config.allItems) {
			shouldRender = true;
		} else {
			if (LootBeams.config.onlyEquipment) {
				shouldRender = isEquipment(stack);
			}

			if (LootBeams.config.onlyRare) {
				shouldRender = stack.getRarity() != Rarity.COMMON;
			}

			if (isItemInRegistryList(LootBeams.config.whitelist, stack.getItem())) {
				shouldRender = true;
			}
		}
		if (isItemInRegistryList(LootBeams.config.blacklist, stack.getItem())) {
			shouldRender = false;
		}

		if (shouldRender) {
			LootBeamRenderer.renderLootBeam(poseStack, buffer, access.lootbeams$getTickDelta(), itemEntity.getWorld().getTime(), itemEntity);
		}
	}

	/**
	 * In 1.21.2+ SwordItem / MiningToolItem / ArmorItem no longer exist: tools and armor are plain items
	 * with the TOOL / EQUIPPABLE data components.
	 */
	private static boolean isEquipment(ItemStack stack) {
		if (stack.contains(DataComponentTypes.TOOL) || stack.contains(DataComponentTypes.EQUIPPABLE)) {
			return true;
		}
		Item item = stack.getItem();
		return item instanceof ShieldItem || item instanceof BowItem || item instanceof CrossbowItem
				|| item instanceof TridentItem || item instanceof ArrowItem || item instanceof FishingRodItem;
	}

	/**
	 * Checks if the given item is in the given list of registry names.
	 */
	private static boolean isItemInRegistryList(List<String> registryNames, Item item) {
		if (registryNames.size() > 0) {
			for (String id : registryNames.stream().filter((s) -> (!s.isEmpty())).toList()) {
				if (!id.contains(":")) {
					if (Registries.ITEM.getId(item).getNamespace().equals(id)) {
						return true;
					}
				}
				Identifier itemResource = Identifier.tryParse(id);
				if (itemResource != null && Registries.ITEM.get(itemResource).asItem() == item.asItem()) {
					return true;
				}
			}
		}
		return false;
	}
}
